## Compiler Project 

Checkpoint #8 / Fully Implemented Compiler 

## Deficiencies: 

Modulus Operator does not work. 
Counting loops do not work. 
