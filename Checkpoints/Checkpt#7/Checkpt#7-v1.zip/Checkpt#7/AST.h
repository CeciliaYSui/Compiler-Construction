/*
 * ========================================================================
 * Author ---------------- Cecilia Y. Sui
 * Course ---------------- Compiler Construction
 * Filename -------------- AST.h
 * Date of Submission ---- November 7, 2019
 * Assignment ------------ Checkpoint #6
 * Description ----------- Build Abstract Syntax Tree
 * ========================================================================
 */

#ifndef AST_H
#define AST_H
#include "ST.h"



// #define like a functional call e.g. 
// #define SQR(x) ((x) * (x))   ?? why parenthese  -- preprocessor time 
// no overhead at computation time (efficiency) faster at run time 
// --> much faster than using normal functions 
// no type checking 
// macro without argument --> manifest constant (has no knowledge of data type)
// e.v. 
// #define PI 3.14159
// fido = PI
// 


// better data type checking 
// enumerables with 
typedef enum{
    ADDITION_OP,
    SUBTRACTION_OP,
    MULTIPLICATION_OP,
    DIVISION_OP,
    MODULUS_OP,
    UMINUS_OP, 
    AND_OP,
    NOT_OP,
    OR_OP,
    LESS_OP,
    GREATER_OP,
    LESSOREQUAL_OP, 
    GREATEROREQUAL_OP,
    NOTEQUAL_OP,
    EQUAL_OP,
    ASSIGNMENT_OP,
    VARIABLE_OP,
    LITERAL_INT,
    LITERAL_REAL, 
    LITERAL_STRING, 
    EXIT_OP, 
    READ_OP, 
    PRINT_OP, 
    COUNTUP_OP, 
    COUNTDOWN_OP, 
    WHILE_OP, 
    IF_OP,
    IFELSE_OP,
    NEWLINE_OP
} OpKind; 


typedef struct Node {
    Type dtype; 
    OpKind kind; // operator kind 
    struct Node *left;
    struct Node *right;
    struct Node *next; 
    int intval;
    float realval; 
    char *sval; 

    struct Node *ifelse; 
    struct Node *cnt1; 
    struct Node *cnt2; 
} Node;


#endif 